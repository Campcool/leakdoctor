# 台灣漏水醫生 網站

## 上線步驟

### 1. 填入以下佔位符（全站搜尋替換）
- `https://lin.ee/rjmmYyC` → 已設定（Line@ 連結）
- `@guleak（待填寫）` → 你的 Line 官方帳號 ID
- `待填寫網域` → 你的網域（如 guleak.tw）
- `待填寫` in SEO/team → 填入真實資料

### 2. 上傳到 GitHub Pages（免費）
1. 申請 GitHub 帳號
2. 建立 repository（例如 `leakdoctor`）
3. 上傳所有檔案
4. Settings → Pages → Branch: main → Save
5. 網址：https://你的帳號.github.io/leakdoctor/

### 3. 提交 Google Search Console
1. 進入 https://search.google.com/search-console
2. 新增網址前置字串
3. 驗證（HTML 標籤方式）→ 填入 index.html 的 meta 驗證欄
4. 提交 sitemap：https://你的網址/sitemap.xml

### 4. 買網域（可選）
- domains.google.com 或 godaddy.com
- .tw 約 NT$400–600/年
- 購買後設定 CNAME 指向 GitHub Pages

## 檔案結構
- index.html（主頁）
- knowledge.html（漏水百科）
- cases.html（施工案例）
- team.html（師傅工班）
- sitemap.xml（Google 索引用）
- robots.txt（搜尋引擎規則）
